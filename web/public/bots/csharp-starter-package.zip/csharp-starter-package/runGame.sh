#!/bin/bash
xbuild /p:Configuration=Release /p:Platform=AnyCpu RandomBot/RandomBot.csproj
xbuild /p:Configuration=Release /p:Platform=AnyCpu MyBot/MyBot.csproj
./halite/halite -d "30 30" "mono MyBot/bin/Release/MyBot.exe" "mono RandomBot/bin/Release/RandomBot.exe" "mono RandomBot/bin/Release/RandomBot.exe" "mono RandomBot/bin/Release/RandomBot.exe"
