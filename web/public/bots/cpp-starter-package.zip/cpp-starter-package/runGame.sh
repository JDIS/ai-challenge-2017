#!/bin/bash
make -C MyBot/
make -C RandomBot/
./halite/halite -d "30 30" "./MyBot/MyBot" "./RandomBot/RandomBot" "./RandomBot/RandomBot" "./RandomBot/RandomBot"
