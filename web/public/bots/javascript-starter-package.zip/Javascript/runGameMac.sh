#!/bin/bash
./halite/haliteMac -d "30 30" "node MyBot/MyBot.js" "node RandomBot/RandomBot.js" "node RandomBot/RandomBot.js" "node RandomBot/RandomBot.js"
