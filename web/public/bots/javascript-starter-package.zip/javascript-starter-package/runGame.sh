#!/bin/bash

./halite -d "30 30" "node MyBot.js" "node RandomBot.js"
