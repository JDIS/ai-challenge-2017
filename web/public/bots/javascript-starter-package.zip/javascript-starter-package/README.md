Don't forget to `npm i`. The project was tested with node 8
